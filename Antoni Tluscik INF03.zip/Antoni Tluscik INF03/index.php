<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wodospady</title>
    <link rel="stylesheet" href="styl.css">
</head>
<body>
    <header><h2>Łowcy wodospadów</h2></header>
    <main>
    <aside>
    <?php
    $host = "localhost";
    $uzytkownik = "root";
    $haslo = "";
    $baza = "wodospady";

    $conn = mysqli_connect($host, $uzytkownik, $haslo, $baza);

    $query = "SELECT * FROM kontynenty";
    $result = mysqli_query($conn, $query);

    while ($row = mysqli_fetch_assoc($result)) {
        echo "<a href='index.php?id=" . $row['idKontynent'] . "'>" . $row['nazwa'] . "</a>";
    }
    ?>
    </aside>
    <section>
        <table>
            <tr>
                <th>Identyfikator</th>
                <th>Państwo</th>
                <th>Nazwa wodospadu</th>
                <th>Wysokość</th>
            </tr>
            <?php
                $idKontynent = isset($_GET['id']) ? $_GET['id'] : 6;
                
                $query3 = "SELECT idObiekt, panstwo, nazwa, wartoscCechy FROM obiekty WHERE idRodzaj = 10 AND idKontynent = $idKontynent;";
                $result = mysqli_query($conn, $query3);

                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr><td>" . $row['idObiekt'] . "</td><td>" . $row['panstwo'] . "</td><td>" . $row['nazwa'] . "</td><td>" . $row['wartoscCechy'] . "</td></tr>";
                }
            ?>
        </table>
        <h4>Wpisz osiągnięcie do bazy</h4>
        <form method="post" action="index.php">
            <label for="idwodospad">identyfikator wodospadu</label>
            <input type="number" name="wodospad" id="idwodospad" required>
            <label for="turysta">turysta</label>
            <select name="turysta" id="turysta">
                <?php
                    $query5 = "SELECT idTurysta, nick FROM turysci";

                    $result = mysqli_query($conn, $query5);
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<option value='" . $row['idTurysta'] . "'>" . $row['nick'] . "</option>";
                    }
                ?>
            </select> 
            <button type="submit" name="submit">Wpisz</button>
        </form>
        <?php
            if (isset($_POST['submit'])) 
            {
                if (!empty($_POST['wodospad']) && !empty($_POST['turysta'])) {
                    $idWodospad = $_POST['wodospad'];
                    $idTurysta = $_POST['turysta'];

                    $query4 = "INSERT INTO osiagniecia VALUES (NULL, $idWodospad, $idTurysta);";

                    mysqli_query($conn, $query4);
                }
            }
        ?>
    </section>
    </main>
    <article>
        <h3>Wodospady w Polsce</h3>
        <img src="kamienczyk.jpg" alt="wodospad">
        <img src="siklawica.jpg" alt="wodospad">
        <img src="siklawa.jpg" alt="wodospad">
        <img src="wilczki.jpg" alt="wodospad">
    </article>
    <footer><p>Autor: Antoni Tluscik (nr.25)</p></footer>
    <?php mysqli_close($conn); ?>
</body>
</html>