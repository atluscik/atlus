<?php

abstract class Postac
{
    public $nazwa;
    public $hp;
    public $maxHp;
    public $atak;
    public $obrona;

    function __construct($nazwa, $hp, $atak, $obrona)
    {
        $this->nazwa = $nazwa;
        $this->maxHp = $hp;
        $this->hp = $hp;
        $this->atak = $atak;
        $this->obrona = $obrona;
    }

    function czyKrytyczne()
    {
        return rand(1, 5) == 1;
    }

    function atakuj($cel)
    {
        $obrazenia = $this->atak - $cel->obrona;

        if ($this->czyKrytyczne()) {
            $obrazenia *= 2;
        }

        $procent = rand(75,125);
        $obrazenia *= round($procent / 100);

        if ($obrazenia < 1) {
            $obrazenia = 1;
        }
        $cel->otrzymajObrazenia($obrazenia);
        return $obrazenia;
    }

    function otrzymajObrazenia($ile)
    {
        $this->hp -= $ile;
        if ($this->hp < 0) {
            $this->hp = 0;
        }
    }

    function czyZyje()
    {
        return $this->hp > 0;
    }

    abstract function opisz();
}

class Bohater extends Postac
{
    function __construct($nazwa)
    {
        parent::__construct($nazwa, 100, 25, 8);
    }

    function opisz()
    {
        echo $this->nazwa . " [BOHATER] | HP " . $this->hp . "/" . $this->maxHp . "| ATK " . $this->atak . "| OBR " . $this->obrona;
    }
}

class Wrog extends Postac
{
    function __construct($nazwa, $hp, $atak, $obrona)
    {
        parent::__construct($nazwa, $hp, $atak, $obrona);
    }

    function opisz()
    {
        echo $this->nazwa . " [WROG] | HP " . $this->hp . "/" . $this->maxHp . "| ATK " . $this->atak . "| OBR " . $this->obrona;
    }
}
