<?php
require "klasy.php";

$bohater = new Bohater("Robot");
$wrog = new Wrog("Woda", 90, 22, 6);

$licznik = 1;
while ($bohater->czyZyje() && $wrog->czyZyje()) {
    echo "RUNDA " . $licznik . "<br>";
    
    $obrazenia = $bohater->atakuj($wrog);
    echo $bohater->nazwa . " zadaje " . $obrazenia . " pkt obrażeń. (" . $wrog->nazwa . ": " . $wrog->hp . "/" . $wrog->maxHp . ")<br>";
    
    if (!$wrog->czyZyje()) {
        break;
    }

    $obrazenia = $wrog->atakuj($bohater);
    echo $wrog->nazwa . " zadaje " . $obrazenia . " pkt obrażeń. (" . $bohater->nazwa . ": " . $bohater->hp . "/" . $bohater->maxHp . ")<br><br>";

    $licznik++;
}

if ($bohater->czyZyje()) {
    echo "<strong>Zwycięstwo: " . $bohater->nazwa . "</strong><br>";
} else {
    echo "<strong>Porażka: " . $bohater->nazwa . "</strong><br>";
}
